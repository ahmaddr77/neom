export default function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '20%' }}>
      <h1>NEOM App</h1>
      <p>مرحباً بك في تطبيق الويب القابل للتثبيت (PWA)!</p>
    </div>
  )
}
